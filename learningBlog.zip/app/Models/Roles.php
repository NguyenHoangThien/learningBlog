<?php namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Helpers\DbExec;
use DB;

class Roles extends Model 
{
	protected $table = 'roles';
	protected $primaryKey = 'rID';
	public $timestamps = false;

	//Retrieving all department type
	
}
